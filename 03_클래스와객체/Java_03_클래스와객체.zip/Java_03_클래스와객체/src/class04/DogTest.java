package class04;

public class DogTest {
	public static void main(String[] args) {
		Dog dog = new Dog();
		dog.name = "마루";
		dog.age = 6;
		
		Dog dog2 = new Dog("마리", 6);
		
		Dog dog3 = new Dog(3);
		System.out.println(dog3.name);
	}
}
