package class04;

public class Dog {
	//필드 정의
	String name;
	int age;
	
	//자동으로 생성이 되어있다(생성자를 정의하지 않으면)
	public Dog() {} //습관처럼 기본생성자는 만들어두자
	
	
//	public Dog(String n, int a) {
//		name = n;
//		age = a;
//	}
	
	public Dog(int age) {
		this("뽀삐", age);
//		this.age = age;
//		this.name = "똘똘이";
	}
	
	
	
	public Dog(String name, int age) {
		//String name = ?
		this.name = name;
		this.age = age;
	}
	
}
