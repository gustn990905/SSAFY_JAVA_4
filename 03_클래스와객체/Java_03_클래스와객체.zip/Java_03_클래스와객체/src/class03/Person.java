package class03;

public class Person {
	String name;
	int age;
	String hobby;
	
	
	//메서드 오버로딩
	void info() {
		System.out.printf("나의 이름은 %s입니다. %n나이는 %d세, 취미는%s입니다.%n", name, age, hobby);
	}
	//메서드 오버로딩
	void info(String name, int age) {
		System.out.println("나의 이름은 "+ name +" 나이는 "+age+"세");
	}

//	아래의 두개는 같은것으로 취급
//	void info(String name, String hobby) {
//		
//	}
//	
//	void info(String hobby, String name) {
//		
//	}
	
	
	
	
	//매개변수
	void study(int time) {
		System.out.println(time+"시간 만큼 공부를 했다!");
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
